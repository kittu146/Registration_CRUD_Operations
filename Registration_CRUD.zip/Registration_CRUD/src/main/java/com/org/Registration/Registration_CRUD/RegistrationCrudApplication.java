package com.org.Registration.Registration_CRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationCrudApplication.class, args);
	}

}
