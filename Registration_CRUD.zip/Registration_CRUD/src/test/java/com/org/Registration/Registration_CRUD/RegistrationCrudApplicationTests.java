package com.org.Registration.Registration_CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
